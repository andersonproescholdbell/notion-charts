# notion charts
This project grabs data from a Notion database, creates a chart, and updates an embed in a Notion page to show the new chart.

Uses Notion API, QuickCharts, and is hosted on AWS Lambda.

https://www.youtube.com/watch?v=aDqxCYRDQNI
https://www.youtube.com/watch?v=RfbUOglbuLc

zip -r9q deploy.zip .
then upload as zip to aws lambda